	
	Sipdroid is an open-source SIP client for Android
	
	See http://sipdroid.org for more info
	
	Copyright (C) 2009 The Sipdroid Open Source Project (http://sipdroid.org)
	Copyright (C) 2008 Hughes Systique Corporation, USA (http://hsc.com)
	Copyright (C) 2006 The Android Open Source Project (http://android.com)
	Copyright (C) 2005 Luca Veltri - University of Parma - Italy (http://mjsip.org)
	
	This file is part of Sipdroid (http://www.sipdroid.org)
	
	Sipdroid is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 3 of the License, or
	(at your option) any later version.
	 
	This source code is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	 
	You should have received a copy of the GNU General Public License
	along with this source code; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
	
	
	The source code was based on:
	
	- Mjsip
	  contributing the original stack,
	  packages org.zoolu.* and where Copyright noted
	
	- Hughes Systique Corporation
	  initial port and development of a Test SIP Client to Google's Android Platform,
	  packages org.sipdroid.* where Copyright noted
	
	Then the Sipdroid Open Source project began with porting to an actual phone,
	the Android Developer Phone 1, and testing basic calls. Therefore also patches to
	the Android Frameworks have been submitted.
	
	As Copyright noted, mostly modules in org.sipdroid.ui.* have been added to
	fully integrate the Client into Android's built-in dialer such as the standard UI
	can be used to initiate calls or ring.
	
	Work has begun to add features like putting calls on-hold, muting, sending DTMF,
	and handing-off between networks.
	
	Welcome to the growing worldwide community of Sipdroid users/developers!
	
	
	i-p-tel GmbH
	March, 2009
